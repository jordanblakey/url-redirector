/**
 * Shared type definitions for the URL Redirector extension
 */
export {};
