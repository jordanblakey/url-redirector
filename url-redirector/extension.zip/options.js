document.addEventListener('DOMContentLoaded', () => {
    const sourceInput = document.getElementById('sourceUrl');
    const targetInput = document.getElementById('targetUrl');
    const addBtn = document.getElementById('addRuleBtn');
    const rulesList = document.getElementById('rulesList');
    // Load rules on startup
    loadRules();
    addBtn.addEventListener('click', () => {
        const source = sourceInput.value.trim();
        const target = targetInput.value.trim();
        if (!source || !target) {
            alert('Please enter both source and target URLs.');
            return;
        }
        addRule(source, target);
    });
    const handleEnter = (e) => {
        if (e.key === 'Enter') {
            addBtn.click();
        }
    };
    sourceInput.addEventListener('keypress', handleEnter);
    targetInput.addEventListener('keypress', handleEnter);
    function loadRules() {
        chrome.storage.local.get(['rules'], (result) => {
            const rules = result.rules || [];
            renderRules(rules);
        });
    }
    function addRule(source, target) {
        chrome.storage.local.get(['rules'], (result) => {
            const rules = result.rules || [];
            // Simple duplicate check could be added here
            rules.push({ source, target, id: Date.now(), count: 0 });
            chrome.storage.local.set({ rules }, () => {
                sourceInput.value = '';
                targetInput.value = '';
                renderRules(rules);
            });
        });
    }
    function deleteRule(id) {
        chrome.storage.local.get(['rules'], (result) => {
            const rules = result.rules || [];
            const newRules = rules.filter((rule) => rule.id !== id);
            chrome.storage.local.set({ rules: newRules }, () => {
                renderRules(newRules);
            });
        });
    }
    function renderRules(rules) {
        rulesList.innerHTML = '';
        if (rules.length === 0) {
            const emptyState = document.createElement('li');
            emptyState.textContent = 'No rules added yet.';
            emptyState.style.textAlign = 'center';
            emptyState.style.color = 'var(--text-secondary)';
            emptyState.style.padding = '12px';
            rulesList.appendChild(emptyState);
            return;
        }
        rules.forEach((rule) => {
            const li = document.createElement('li');
            li.className = 'rule-item';
            const contentDiv = document.createElement('div');
            contentDiv.className = 'rule-content';
            const ruleLineDiv = document.createElement('div');
            ruleLineDiv.className = 'rule-line';
            const sourceSpan = document.createElement('span');
            sourceSpan.className = 'rule-source';
            sourceSpan.textContent = rule.source;
            const arrowSpan = document.createElement('span');
            arrowSpan.className = 'rule-arrow';
            arrowSpan.textContent = '➜';
            const targetSpan = document.createElement('span');
            targetSpan.className = 'rule-target';
            targetSpan.textContent = rule.target;
            ruleLineDiv.appendChild(sourceSpan);
            ruleLineDiv.appendChild(arrowSpan);
            ruleLineDiv.appendChild(targetSpan);
            const countSpan = document.createElement('span');
            countSpan.className = 'rule-count';
            const count = rule.count || 0;
            countSpan.textContent = `Used ${count} time${count !== 1 ? 's' : ''}`;
            contentDiv.appendChild(ruleLineDiv);
            contentDiv.appendChild(countSpan);
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'delete-btn';
            deleteBtn.textContent = 'Delete';
            deleteBtn.onclick = () => deleteRule(rule.id);
            li.appendChild(contentDiv);
            li.appendChild(deleteBtn);
            rulesList.appendChild(li);
        });
    }
});
export {};
